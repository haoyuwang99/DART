# RDMonitor — review bundle

Transition-level representation-drift monitoring for agent misbehavior, with a precision-gated
mitigation layer. Contents:

## code/
The clean reference layer (everything else — 66 scratch scripts — is archived under `appendix/` in
the working tree and not included here).
- `rd_agent.py`   — reference primitives: `HiddenLM` (in-process white-box hidden states via
                    `introspect`), `read` (difference-of-means reading direction), `Monitor`,
                    `MonitoredAgent` (online Algorithm 1), `_parse_calls`, `auroc`.
- `rdeval.py`     — THE evaluation script (one concise layer over `rd_agent.py`). Shared core
                    (`fit_um`, `detection_auroc`, `mit_cell`, `report`) + one adapter per dataset
                    (`run_mt`, `run_agentdojo`), both emitting a common per-trajectory record.
                    Run:    `python rdeval.py <model_id> [agentdojo,mt] [n]`  -> rdeval_records.jsonl
                    Report: `python rdeval.py --report`
- `introspect.py` — hidden-state capture dependency of `rd_agent`.

Fixed protocol implemented: enforcement {none, stop, verbalize, directive} x threshold tau in [0,1]
(= target benign-FPR, val-calibrated, applied to test); score = max transition (AgentDojo) /
cumulative drift (h_n - h_0).u (MT); ASR (harmful) + Utility (benign), each by the benchmark's own
checker. 6 models x 2 datasets.

## logs/
- `rdeval_grid.log`     — stdout of the full 6x2 run (n=10).
- `rdeval_records.jsonl`— the raw per-trajectory records the report is computed from.
- `report.txt`          — the two rendered tables (detection AUROC; ASR/Utility grid).

## paper/
`latex/` — compile from the parent of `latex/` with `pdflatex latex/main` (ACL template; sections
are `\input{latex/...}` from `main.tex`). The results above are written into `latex/eval.tex`,
§RQ2 (End-to-end mitigation, `\label{sec:mit-protocol}`): protocol + Tables `tab:mit-schema`
(worked cell), `tab:mit-detect` (detection AUROC), `tab:mit-tau0` (mitigation at tau=0).

## Headline result
Detection precision gates mitigation: a precise gate + hard `stop` yields ASR 0 at preserved
utility (all MT; AgentDojo 32B/30B-A3B/Mistral); a weak gate bounds mitigation but never
over-refuses (flag_b ~ 0 -> Utility held). Enforcement order stop > directive > verbalize.

Caveats: n=10 per split (±~0.14); AgentDojo = slack suite, trajectory-level gate (harder than the
per-context 0.93 of RQ1); MT metric via a keyword refusal classifier; AgentDojo `verbalize` is a
fixed injection reminder (MT's is model-derived).
